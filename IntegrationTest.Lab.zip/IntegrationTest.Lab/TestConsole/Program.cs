﻿#region 測試 取得本機可用的 Port

// var freePort = TestUtility.Network.GetLocalFreePortUtility.Get(49152, 65535);
// Console.WriteLine(freePort);

#endregion

#region 測試 Docker Container SqlServer2019 

// using System.Data.SqlClient;
// using TestUtility.Docker;
//
// var freePort = TestUtility.Network.GetLocalFreePortUtility.Get(49152, 65535);
// var dockerContainerInfo = DockerContainerProvider.SqlServer.SqlServer2019(freePort);
//
// try
// {
//     using (var connection = new SqlConnection(dockerContainerInfo.ConnectionString))
//     {
//         connection.Open();
//     }
//
//     Console.WriteLine("SQL Server connection test succeeded.");
// }
// catch (Exception ex)
// {
//     Console.WriteLine($"SQL Server connection test failed: {ex.Message}");
// }
// finally
// {
//     dockerContainerInfo.Container?.Dispose();
// }

#endregion

Console.Write("TestConsole");

