﻿using System.Data.SqlClient;
using Dapper;

namespace TestUtility.Database.SqlServer;

public static class Command
{
    public static void Execute(string connectionString, string sqlCommand)
    {
        var conn = new SqlConnection(connectionString);
        conn.Execute(sqlCommand);
    }
}