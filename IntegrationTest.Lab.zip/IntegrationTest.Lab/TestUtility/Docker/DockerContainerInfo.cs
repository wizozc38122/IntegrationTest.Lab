﻿using Ductus.FluentDocker.Services;

namespace TestUtility.Docker;

public class DockerContainerInfo
{
    public IContainerService? Container { get; set; }
    public string? ConnectionString { get; set; }
}