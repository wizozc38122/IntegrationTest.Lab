﻿using Ductus.FluentDocker.Builders;
using TestUtility.Docker.Setting;

namespace TestUtility.Docker;

/// <summary>
/// 提供Docker Container
/// </summary>
public static class DockerContainerProvider
{
    /// <summary>
    /// MongoDb
    /// </summary>
    public static class MongoDb
    {
        /// <summary>
        /// MongoDb 4.0.0
        /// </summary>
        /// <param name="containerPort"></param>
        /// <returns></returns>
        public static DockerContainerInfo MongoDb400(int containerPort)
        {
            var setting = DockerSettingsProvider.MongoDb.MongoDb400;
            return new DockerContainerInfo
            {
                Container = new Builder().UseContainer()
                    .UseImage(setting.ImageName)
                    .ExposePort(containerPort, setting.ExposePort)
                    .WaitForPort($"27017/tcp", 60 * 1000)
                    .WithName(setting.ContainerName)
                    .Build()
                    .Start(),
                ConnectionString = string.Format(setting.ConnectionString, $"{containerPort}")
            };
        }
    }
    
    /// <summary>
    /// SqlServer
    /// </summary>
    public static class SqlServer
    {
        /// <summary>
        /// SqlServer 2019 
        /// </summary>
        /// <param name="localPort"></param>
        /// <returns></returns>
        public static DockerContainerInfo SqlServer2019(int localPort)
        {
            var setting = DockerSettingsProvider.SqlServer.SqlServer2019;
            return new DockerContainerInfo
            {
                Container = new Builder().UseContainer()
                    .UseImage(setting.ImageName)
                    .ExposePort(localPort, setting.ExposePort)
                    .WithEnvironment(setting.Environment.ToArray())
                    .WaitForMessageInLog(setting.WaitForMessageInLog)
                    .WithName(setting.ContainerName)
                    .Build()
                    .Start(),
                ConnectionString = string.Format(setting.ConnectionString, $"{localPort}")
            }; 
        }

    }
}
