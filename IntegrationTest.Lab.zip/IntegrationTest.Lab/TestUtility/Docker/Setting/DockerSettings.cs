namespace TestUtility.Docker.Setting;

/// <summary>
/// Docker Setting
/// </summary>
public class DockerSettings
{
    public string ContainerName { get; set; } = string.Empty;
    public string ImageName { get; set; } = string.Empty;
    public int ExposePort { get; set; }
    public IEnumerable<string> Environment { get; set; } = new List<string>();
    public string WaitForMessageInLog { get; set; } = string.Empty;
    public string ConnectionString { get; set; } = string.Empty; 
}