﻿namespace TestUtility.Docker.Setting;

/// <summary>
/// Docker Settings Provider
/// 可抽離 Json 檔
/// </summary>
public class DockerSettingsProvider
{
    /// <summary>
    /// 區分測試用Docker
    /// (可改為專案名稱)
    /// </summary>
    private const string Prefix = "TestUtility.Docker";
    
    /// <summary>
    /// Container Name
    /// </summary>
    private static Func<string, string> ContainerName => name => $"{Prefix}.{name}";
    
    /// <summary>
    /// MongoDb
    /// </summary>
    public static class MongoDb
    {
        public static readonly DockerSettings MongoDb400 = new DockerSettings
        {
            ContainerName = ContainerName("MongoDb400"),
            ImageName = "mongo:4.0.0",
            ExposePort = 27017,
            ConnectionString = "mongodb://localhost:{0}"
        };
    }
    
    /// <summary>
    /// SqlServer
    /// </summary>
    public static class SqlServer
    {
        public static readonly DockerSettings SqlServer2019 = new DockerSettings
        {
            ContainerName = ContainerName("SqlServer2019"),
            ImageName = "mcr.microsoft.com/mssql/server:2019-latest",
            ExposePort = 1433,
            Environment = new List<string> { "ACCEPT_EULA=Y", "SA_PASSWORD=@Aa123456" },
            WaitForMessageInLog = "The default language (LCID 0) has been set for engine and full-text services",
            ConnectionString = "Server=localhost,{0};Database=master;MultipleActiveResultSets=True;User ID='sa';Password='@Aa123456'"
        };
    }
}