﻿using System.Net.NetworkInformation;

namespace TestUtility.Network;

/// <summary>
/// 取得Local Free Port
/// </summary>
public static class GetLocalFreePortUtility
{
    /// <summary>
    /// 取得範圍內的Free Port
    /// </summary>
    /// <param name="rangeMin"></param>
    /// <param name="rangeMax"></param>
    /// <returns></returns>
    public static int Get(int rangeMin, int rangeMax)
    {
        // Get Used Tcp Port
        var ipGlobalProperties = IPGlobalProperties.GetIPGlobalProperties();
        var tcpConnInfoArray = ipGlobalProperties.GetActiveTcpConnections();
        var tcpPortCollection = tcpConnInfoArray.Where(tcp => tcp.LocalEndPoint.Port >= rangeMin)
            .Where(tcp => tcp.LocalEndPoint.Port <= rangeMax)
            .Select(tcp => tcp.LocalEndPoint.Port);

        // Gen Range To Except
        var range = Enumerable.Range(rangeMin, rangeMax - rangeMin + 1).ToList();
        var freePort = range.Except(tcpPortCollection).ToList();
        
        return freePort.Skip(new Random().Next(0, freePort.Count - 1)).Take(1).FirstOrDefault();
    }
}