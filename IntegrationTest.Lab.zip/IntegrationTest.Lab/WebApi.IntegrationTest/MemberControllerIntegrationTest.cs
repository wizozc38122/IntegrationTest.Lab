using System.Text;
using System.Text.Json;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestUtility.Docker;
using WebApi.Repository;
using WebApi.Repository.Parameter;

namespace WebApi.IntegrationTest;

[TestClass]
public class MemberControllerIntegrationTest
{
    private static WebApplicationFactory<Program> _webApplicationFactory;
    private static DockerContainerInfo _sqlServer2019;

    [ClassInitialize]
    public static void TestInitialize(TestContext context)
    {
        var port = TestUtility.Network.GetLocalFreePortUtility.Get(49152, 65535);
        _sqlServer2019 = DockerContainerProvider.SqlServer.SqlServer2019(port);
        
        TestUtility.Database.SqlServer.Command.Execute(_sqlServer2019.ConnectionString ,"CREATE DATABASE [Lab]");
        TestUtility.Database.SqlServer.Command.Execute(_sqlServer2019.ConnectionString ,@"CREATE TABLE [Lab].[dbo].[Member]
        (
            Id INT IDENTITY(1,1) PRIMARY KEY,
            Account NVARCHAR(30) NOT NULL,
            Name NVARCHAR(30) NOT NULL,
            Age INT
        )");
        
        _webApplicationFactory = new WebApplicationFactory<Program>();
        _webApplicationFactory = _webApplicationFactory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureTestServices(services =>
            {
                services.Configure<SqlServerConnectionOptions>(options =>
                {
                    options.SqlServer = _sqlServer2019.ConnectionString;
                });
            });
        });
    }

    [ClassCleanup]
    public static void ClassCleanup()
    {
        _webApplicationFactory.Dispose();
        _sqlServer2019.Container.Dispose();
    }

    [TestMethod]
    public async Task 測試建立Member_驗證測試成功_回傳200()
    {
        // Arrange
        var client = _webApplicationFactory.CreateClient();
        var parameter = new CreateMemberParameter()
        {
            Account = "Account",
            Name = "Qin",
            Age = 100
        };
        var request = new HttpRequestMessage
        {
            Method = new HttpMethod("POST"),
            RequestUri = new Uri($"/Member", UriKind.RelativeOrAbsolute),
            Content = new StringContent(JsonSerializer.Serialize(parameter), Encoding.UTF8, "application/json")
        };

        // Act
        var response = await client.SendAsync(request);

        // Assert
        response.Should().Be200Ok();
    }
}