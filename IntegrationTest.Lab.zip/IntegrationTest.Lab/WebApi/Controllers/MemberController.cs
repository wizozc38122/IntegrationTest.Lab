using System.Net;
using Microsoft.AspNetCore.Mvc;
using WebApi.Repository;
using WebApi.Repository.Parameter;

namespace WebApi.Controllers;

[ApiController]
[Route("[controller]")]
public class MemberController : ControllerBase
{
    private readonly IMemberRepository _memberRepository;

    public MemberController(IMemberRepository memberRepository)
    {
        _memberRepository = memberRepository;
    }

    /// <summary>
    /// 取得會員資訊
    /// </summary>
    /// <param name="account"></param>
    /// <returns></returns>
    [HttpGet]
    public async Task<IActionResult> GetMemberInfoAsync(string account)
    {
        var memberInfo = await _memberRepository.GetMemberInfoAsync(account);

        return memberInfo is not null ? Ok(memberInfo) : NotFound();
    }

    /// <summary>
    /// 建立會員
    /// </summary>
    /// <param name="parameter"></param>
    /// <returns></returns>
    [HttpPost]
    public async Task<IActionResult> CreateMemberAsync(CreateMemberParameter parameter)
    {
        var isExists = await _memberRepository.CheckAccountIsExistAsync(parameter.Account);
        if (isExists)
        {
            return BadRequest("Account is exists.");
        }

        var result = await _memberRepository.CreateMemberAsync(parameter);
        return result ? Ok() : StatusCode((int)HttpStatusCode.InternalServerError);
    }
}