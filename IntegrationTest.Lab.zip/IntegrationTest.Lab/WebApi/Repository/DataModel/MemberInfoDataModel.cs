﻿namespace WebApi.Repository.DataModel;

public class MemberInfoDataModel
{
    public string Account { get; set; }
    public string Name { get; set; }
    public int Age { get; set; }
}