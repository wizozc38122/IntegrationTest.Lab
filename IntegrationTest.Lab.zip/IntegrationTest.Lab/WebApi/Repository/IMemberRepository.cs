﻿using WebApi.Repository.DataModel;
using WebApi.Repository.Parameter;

namespace WebApi.Repository;

public interface IMemberRepository
{
    /// <summary>
    /// 建立會員
    /// </summary>
    /// <param name="memberInfo"></param>
    /// <returns></returns>
    Task<bool> CreateMemberAsync(CreateMemberParameter memberInfo);

    /// <summary>
    /// 取得會員資料
    /// </summary>
    /// <param name="account"></param>
    /// <returns></returns>
    Task<MemberInfoDataModel?> GetMemberInfoAsync(string account);
    
    /// <summary>
    /// 確認是帳號是否存在
    /// </summary>
    /// <param name="account"></param>
    /// <returns></returns>
    Task<bool> CheckAccountIsExistAsync(string account);
}