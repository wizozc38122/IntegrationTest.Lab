﻿using System.Data.SqlClient;
using Dapper;
using Microsoft.Extensions.Options;
using WebApi.Repository.DataModel;
using WebApi.Repository.Parameter;

namespace WebApi.Repository;

public class MemberRepository : IMemberRepository
{
    private readonly SqlServerConnectionOptions _sqlServerConnectionOptions;

    public MemberRepository(IOptions<SqlServerConnectionOptions> sqlServerConnectionOptions)
    {
        _sqlServerConnectionOptions = sqlServerConnectionOptions.Value;
    }
    
    public async Task<bool> CreateMemberAsync(CreateMemberParameter memberInfo)
    {
        using var conn = new SqlConnection(_sqlServerConnectionOptions.SqlServer);

        const string sql = "INSERT INTO [Lab].[dbo].[Member] (Account, Name, Age) VALUES (@Account, @Name, @Age)";

        var effectCount = await conn.ExecuteAsync(sql, memberInfo);

        return effectCount > 0;
    }

    public async Task<MemberInfoDataModel?> GetMemberInfoAsync(string account)
    {
        using var conn = new SqlConnection(_sqlServerConnectionOptions.SqlServer);

        const string sql = "SELECT * FROM [Lab].[dbo].[Member] WHERE Account = @Account";
        
        return await conn.QueryFirstOrDefaultAsync<MemberInfoDataModel>(sql, new { Account = account });
    }
    
    public async Task<bool> CheckAccountIsExistAsync(string account)
    {
        using var conn = new SqlConnection(_sqlServerConnectionOptions.SqlServer);

        const string sql = "SELECT COUNT('x') FROM [Lab].[dbo].[Member] WHERE Account = @Account";
        
        return await conn.QueryFirstOrDefaultAsync<int>(sql, new { Account = account }) > 0;
    }
}