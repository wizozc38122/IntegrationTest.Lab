﻿namespace WebApi.Repository.Parameter;

public class CreateMemberParameter
{
    public string Account { get; set; }
    public string Name { get; set; }
    public int? Age { get; set; }
}