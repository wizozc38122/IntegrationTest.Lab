﻿namespace WebApi.Repository;

public class SqlServerConnectionOptions
{
    public string SqlServer { get; set; }
}